create schema if not exists magic;
create table magic.allsets(data jsonb);
